Penting!

1. Isi data di main.tex dari line 54-73
2. Default template ini adalah untuk penulsian proposal tugas akhir. Untuk merubah ke format Tugas Akhir aktifkan "\logTAtrue" pada line 75